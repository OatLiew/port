package com.example.hw2;


import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import java.util.logging.Handler;

import com.example.hw2.R;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Surface;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.TimePicker;


/**
 * Create main activity
 * The application implements an option menu or button 
 * on the main screen that allows the creation and 
 * storage of a single alarm that allows the User to 
 * select a time to have the alarm fire. When the set 
 * alarm time is hit, the application will change the 
 * color of the current time from the default White 
 * (Hex FFFFFF) to Red (Hex FF0000) for 5 seconds. 
 * After 5 seconds, the color of the current time will 
 * revert back to White (Hex FFFFFF).
 */
public class MainActivity extends Activity {
	final Context context = this;
	private TextView timeView;
	private TextView setView;
	private Button setButton;
	private Button resetButton;
	private int timePickerHour;
	private int timePickerMinute;
	private int calendarHour;
	private int calendarMinute;
	private int calendarSecond;
	private int hour;
	private int minute;
	private String second;
	private int count = 0; // count to 5 seconds
	private boolean colorOn;
    
	static final int TIME_DIALOG_ID = 999;

    
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		timePickerHour = 0;
		timePickerMinute = 0;
		hour = 1;
		minute = 1;
		//get text field
	    timeView  = (TextView)this.findViewById(R.id.time);
	    setView  = (TextView)this.findViewById(R.id.settime);
	    
	    Typeface typeFace=Typeface.createFromAsset(getAssets(),"fonts/Iceland-Regular.ttf");
	    timeView.setTypeface(typeFace);
	    
		//get buttons
		setButton = (Button)this.findViewById(R.id.start_btn);
		
		setButton.setText("Set_Time");
					
		setButton.setOnClickListener(sethandler);
		
		showCurrentTime();
		
	}
	/**
	 * Change the background color to red
	 */
	public void setActivityBackgroundRed() {
	    View view = this.getWindow().getDecorView();
	    view.setBackgroundColor(Color.RED);
	}
	
	/**
	 * Create background color to White
	 */
	public void setActivityBackgroundWhite() {
	    View view = this.getWindow().getDecorView();
	    view.setBackgroundColor(Color.WHITE);
	}
	
	
	/**
	 * Display current time using new thread
	 */
	private void showCurrentTime(){
		
		Thread t = new Thread() {

			  @Override
			  public void run() {
			    try {
			      while (!isInterrupted()) {
			        Thread.sleep(1000);
			        
			        runOnUiThread(new Runnable() {
			          @Override
			          public void run() {
			        	  
			        	String mydate = java.text.DateFormat.getTimeInstance().format(Calendar.getInstance().getTime());			      		
			      		timeView.setText(mydate);
			      		
			      		//get minute and hours
			      		Calendar c = Calendar.getInstance(); 
			      		calendarMinute = c.get(Calendar.MINUTE);	
			      		calendarHour = c.get(Calendar.HOUR_OF_DAY); 
			      		calendarSecond = c.get(Calendar.SECOND);
			      		second = Integer.toString(calendarSecond);
			      		
			      		// compare the hours and minute
			    		if (calendarHour == hour && calendarMinute == minute) {
			    			
			    			count = count+1;
			    			//String se = Integer.toString(count);
			    			//setButton.setText(se);
			    			
			    			if((count < 5) && (colorOn == false)){
			    				setActivityBackgroundRed();
			    			}
			    			else{
			    				setActivityBackgroundWhite();
			    				count = 0;
			    				colorOn = true;
			    			}
			    		}
			          }
			        });
			      }
			    } catch (InterruptedException e) {}
			  }
			};
			
		t.start();
		
		
	}

	View.OnClickListener sethandler = new View.OnClickListener() {
		
	   @Override	
	   public void onClick(View v) {
	   	
	    	//timepicker.clearFocus();
	    	showDialog(TIME_DIALOG_ID);
	    	
	    }
	  };
	  
 
	@Override
	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case TIME_DIALOG_ID:
			// set time picker as current time
			return new TimePickerDialog(this,timePickerListener, hour, minute,false);
 
		}
		return null;
	}
 
	/**
	 * Display the set time from TimePicker
	 */
	private TimePickerDialog.OnTimeSetListener timePickerListener = 
            new TimePickerDialog.OnTimeSetListener() {
		public void onTimeSet(TimePicker view, int selectedHour,
				int selectedMinute) {
			hour = selectedHour;
			minute = selectedMinute;
 
			// set current time into textview
			setView.setText(new StringBuilder().append(pad(hour))
					.append(":").append(pad(minute)));
			colorOn = false;// use for checking for 5 secs condition  
 
		}
	};
	
	/**
	 * display the hour and minute
	 * @param  c the value for hour and minute
	 * @return  string of the values after converting
	 **/
	
	private static String pad(int c) {
		if (c >= 10)
		   return String.valueOf(c);
		else
		   return "0" + String.valueOf(c);
	}

}
